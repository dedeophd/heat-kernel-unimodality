"""Independent integer walk-count diagnostics for the all-level identities.

Enumerates actual ring graphs; no spectral formula builds these counts.
Finite diagnostics supplement, and do not prove, the all-level argument.
"""
from pathlib import Path
from math import gcd
import json


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def chi(a, p):
    return 0 if a % p == 0 else (1 if pow(a % p, (p-1)//2, p) == 1 else -1)


def valuation(a, p, n):
    if a == 0:
        return n
    k = 0
    while k < n and a % p == 0:
        a //= p
        k += 1
    return k


def graph_counts(p, n):
    m = p**n
    units = [y for y in range(m) if gcd(y, p) == 1]
    vertices = [(x, y) for x in range(m) for y in units]
    index = {g: i for i, g in enumerate(vertices)}
    sphere = [(x, y) for x, y in vertices if (x*x+y*y+1) % m == 0]
    require(len(sphere) == (p+1)*p**(n-1), 'ring degree')
    current = [0]*len(vertices)
    current[index[(0, 1)]] = 1
    counts = [current]
    for step in range(3):
        nxt = [0]*len(vertices)
        for i, c in enumerate(current):
            if c:
                x, y = vertices[i]
                for u, v in sphere:
                    nxt[index[((x+y*u) % m, y*v % m)]] += c
        current = nxt
        counts.append(current)
        require(sum(current) == len(sphere)**(step+1), 'total path count')
    return vertices, index, counts


def main():
    cases = {3: [1, 2, 3, 4], 7: [1, 2], 11: [1, 2]}
    records = []
    for p, levels in cases.items():
        graphs = {n: graph_counts(p, n) for n in levels}
        fv, fi, fc = graphs[1]
        for n in levels[1:]:
            vertices, index, counts = graphs[n]
            ov, oi, oc = graphs[n-1]
            m = p**n
            oldm = m//p
            N, oldN = len(vertices), len(ov)
            localized = near_source = 0
            for i, (x, y) in enumerate(vertices):
                j = oi[(x % oldm, y % oldm)]
                # Density form of P^3 E_n = (4 p^n / d_n^2) P E_n.
                require(N*counts[3][i]-oldN*p**3*oc[3][j]
                        == 4*p**n*(N*counts[1][i]-oldN*p*oc[1][j]),
                        'exact new-sector cubic source row')
                f = fi[(x % p, y % p)]
                special = (x % p == 0 and y % p in [1, p-1])
                if not special and fc[1][f] == 0:
                    require(counts[2][i] == fc[2][f], 'generic two-jump localization')
                    localized += 1
                if special:
                    k = valuation(x, p, n)
                    r = valuation(1-y*y, p, n)
                    if min(k, r) == n:
                        predicted = (p+1)*p**(n-1)
                    elif k != r:
                        predicted = 0
                    else:
                        u = ((x*x+y*y-1)//p**k)*pow(2*(x//p**k), -1, p) % p
                        predicted = p**k*(1+chi(-u*u-1, p))
                    require(counts[2][i] == predicted, 'source-pair valuation profile')
                    near_source += 1
            record = {'p': p, 'n': n, 'vertices': N,
                      'cubic_rows_checked': N, 'localized_coordinates': localized,
                      'source_pair_profiles_checked': near_source, 'status': 'passed'}
            records.append(record)
            print(record, flush=True)
    out = Path('output')
    out.mkdir(exist_ok=True)
    (out/'Tower_Identity_Verification.json').write_text(json.dumps({
        'status': 'passed', 'arithmetic': 'Python integers; direct ring graph walks',
        'scope': 'finite diagnostics, not a proof for all primes or levels',
        'records': records}, indent=2)+'\n')


if __name__ == '__main__':
    main()
