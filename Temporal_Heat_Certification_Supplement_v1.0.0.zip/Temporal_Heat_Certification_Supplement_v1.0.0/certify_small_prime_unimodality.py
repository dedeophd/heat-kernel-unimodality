"""Certified finite part of the all-level p=7,11,19 unimodality proof.

Exact graph-neighbor quotient, exact real-root isolation (SymPy), and rigorous
Arb interval arithmetic (python-flint). No uncertified floating-point sign tests are used.
The accompanying note proves the reduction from all levels to these checks.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json
import sympy as sp
from flint import arb, ctx
from verify_prime_bridge import geometric_quotient

ctx.prec = 384
X = sp.Symbol('X')


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def rational(x):
    return F(int(sp.numer(x)), int(sp.denom(x)))


def aa(x):
    x = F(x)
    return arb(x.numerator)/x.denominator


def ball(lo, hi):
    return aa(lo).union(aa(hi))


def horner(coeff, x):
    y = arb(0)
    for c in coeff:
        y = y*x+aa(c)
    return y


def sign(x):
    return 1 if x > 0 else (-1 if x < 0 else 0)


def spectral_data(p):
    squares, Q = geometric_quotient(p)
    M = sp.Matrix(Q)
    f = sp.Poly(M.charpoly(X).as_expr(), X)
    require(sp.gcd(f, f.diff()).degree() == 0, 'simple folded spectrum')
    roots = []
    for ff, multiplicity in sp.factor_list(f)[1]:
        require(multiplicity == 1, 'squarefree factors')
        for (lo, hi), mul in ff.intervals(eps=sp.Rational(1, 10**90)):
            require(mul == 1, 'simple real root')
            lo, hi = rational(lo), rational(hi)
            roots.append({'lo': lo, 'hi': hi, 'factor': ff,
                          'value': ball(lo, hi)})
    roots.sort(key=lambda r: r['lo'])
    require(len(roots) == len(Q), 'all eigenvalues isolated as real roots')
    require(all(a['hi'] < b['lo'] for a, b in zip(roots, roots[1:])), 'root order')
    require(roots[-1]['lo'] == roots[-1]['hi'] == p+1, 'constant eigenvalue')
    require(roots[0]['lo'] > -(p+1), 'all nonconstant frequencies have modulus less than one')
    source = squares.index(4)
    v = [int(i == source) for i in range(len(Q))]
    cols = [v]
    # adj(XI-Q) column, via the characteristic-polynomial recurrence.
    for c in f.all_coeffs()[1:-1]:
        v = [sum(row[j]*v[j] for j in range(len(Q)))+int(c)*int(i == source)
             for i, row in enumerate(Q)]
        cols.append(v)
    numerators = [sp.Poly(sum(cols[j][i]*X**(len(Q)-1-j)
                             for j in range(len(Q))), X) for i in range(len(Q))]
    coeff = []
    for num in numerators:
        row = []
        for r in roots:
            if num.rem(r['factor']).is_zero:
                row.append(arb(0))
            else:
                val = aa(F(p*(p-1), 2))*horner(num.all_coeffs(), r['value'])
                val /= horner(f.diff().all_coeffs(), r['value'])
                require(sign(val) != 0, 'projector coefficient sign isolated')
                row.append(val)
        coeff.append(row)
    return squares, Q, f, roots, coeff


def eval_sum(terms, t, derivative=0):
    return sum((c*(mu if derivative else 1)*(mu*t).exp() for mu, c in terms), arb(0))


def certify_profile(p, Q, idx, roots, coefficients):
    d = p+1
    raw = [(r['value']/d, -c*(1-r['value']/d))
           for r, c in zip(roots[:-1], coefficients[:-1]) if sign(c)]
    require(raw, 'nonconstant terms')
    top = raw[-1][0]
    terms = [(lam-top, c) for lam, c in raw[:-1]]+[(arb(0), raw[-1][1])]
    top_sign = sign(raw[-1][1])
    # Exact Taylor coefficients of e^t h'(t) from graph path counts.
    squares = sorted({x*x % p for x in range(p)})
    source = squares.index(4)
    v = [int(i == source) for i in range(len(Q))]
    density = []
    for j in range(19):
        density.append(F(p*(p-1)*v[idx], 2*d**j))
        v = [sum(row[k]*v[k] for k in range(len(Q))) for row in Q]
    tay = [(density[j+1]-density[j])/factorial(j) for j in range(18)]
    r0 = next(j for j, c in enumerate(tay) if c)
    require(r0 in [1, 2] and tay[r0] > 0, 'initial derivative order and sign')
    eps = F(1, 64)
    # All |lambda|<1. Bound the divided Taylor remainder uniformly to zero.
    lower = aa(tay[r0]-sum(abs(tay[j])*eps**(j-r0) for j in range(r0+1, 18)))
    remainder = sum((abs(c) for _, c in raw), arb(0))*aa(eps).exp()
    remainder *= aa(eps**(18-r0)/factorial(18))
    require(lower-remainder > 0, 'positive initial interval including t=0')
    T = 8
    while T <= 4096:
        tail = abs(terms[-1][1])-sum((abs(c)*(mu*T).exp() for mu, c in terms[:-1]), arb(0))
        if tail > 0:
            break
        T *= 2
    require(T <= 4096 and tail > 0, 'signed infinite tail')
    stack = [(eps, F(T))]
    leaves = []
    crossings = []
    while stack:
        lo, hi = stack.pop()
        box = ball(lo, hi)
        val = eval_sum(terms, box)
        if sign(val):
            leaves.append([str(lo), str(hi), 'signed', sign(val)])
            continue
        slope = eval_sum(terms, box, 1)
        sl, sh = sign(eval_sum(terms, aa(lo))), sign(eval_sum(terms, aa(hi)))
        if sign(slope) and sl and sh:
            leaves.append([str(lo), str(hi), 'monotone', sl, sh, sign(slope)])
            if sl != sh:
                crossings.append([str(lo), str(hi), sl, sh])
            continue
        require(hi-lo > F(1, 2**50), f'interval subdivision terminated p={p} s={squares[idx]} lo={lo} hi={hi} g={val} slope={slope} point={eval_sum(terms,aa((lo+hi)/2))}')
        mid = (lo+hi)/2
        stack.extend([(mid, hi), (lo, mid)])
    leaves.sort(key=lambda l: F(l[0]))
    require(F(leaves[0][0]) == eps and F(leaves[-1][1]) == T, 'finite interval covered')
    require(all(a[1] == b[0] for a, b in zip(leaves, leaves[1:])), 'no partition gaps')
    expected = 0 if top_sign > 0 else 1
    require(len(crossings) == expected, 'zero or one positive maximum')
    require(all(c[2:] == [1, -1] for c in crossings), 'only a maximum')
    return {'folded_class': squares[idx], 'initial_order': r0,
            'initial_interval': ['0', str(eps)], 'initial_sign': 'positive',
            'infinite_tail_from': T, 'infinite_tail_sign': top_sign,
            'positive_derivative_zeros': len(crossings), 'crossings': crossings,
            'certified_partition': leaves}


def tower_checks(p, roots, coeff, squares):
    nonconstant = roots[:-1]
    require(nonconstant[0]['hi'] < -2 and nonconstant[-1]['lo'] > 2,
            'outer field eigenvalues dominate every new-sector frequency')
    for r in nonconstant:
        lo, hi = r['lo'], r['hi']
        require(lo > 0 or hi < 0, 'no zero field eigenvalue')
        lower = lo if lo > 0 else -hi
        require(lower*lower > F(4, p), 'all field frequencies outside level-three window')
    output = {}
    for name, s in [('U1', 0), ('A1', 4)]:
        cs = coeff[squares.index(s)]
        terms = {j: -c*(1-r['value']/(p+1)) for j, (r, c) in enumerate(zip(nonconstant, cs))}
        extras = {}
        if name == 'U1':
            b = F(2, p+1);C = -F(p*(p-1), p+1)
            extras[-2] = aa(C*(1+b)/(2*b))
            extras[2] = aa(-C*(1-b)/(2*b))
        else:
            b = F(2, p+1);C = -F(p*(p-1), p+1)
            extras[-2] = aa(-C*(1+b)/(2*b*b))
            extras[2] = aa(-C*(1-b)/(2*b*b))
            extras[0] = aa(F(p*(p-1), 2)+C/(b*b))
        ordered = []
        for j, r in enumerate(nonconstant):
            key = next((z for z in list(extras) if r['lo'] == r['hi'] == z), None)
            c = terms[j]+extras.pop(key) if key is not None else terms[j]
            require(sign(c) != 0, 'field and rational coefficients resolved')
            ordered.append((r['lo'], r['hi'], sign(c)))
        ordered += [(F(z), F(z), sign(c)) for z, c in extras.items()]
        ordered.sort(key=lambda z: z[0])
        require(all(a[1] < b[0] for a, b in zip(ordered, ordered[1:])), 'frequency order including ties')
        signs = [s for _, _, s in ordered]
        variation = sum(a != b for a, b in zip(signs, signs[1:]))
        require(variation == (3 if name == 'U1' else 4), 'exceptional profile sign variation')
        output[name] = {'coefficient_signs_in_increasing_frequency': signs,
                        'sign_changes': variation}
    return output


def main():
    result = {'scope': 'p=7,11,19, all ring levels, conditional only on the proved cubic/profile reduction',
              'arithmetic': 'exact integer quotient and characteristic polynomial; exact rational root isolation; Arb certified intervals at 384 bits',
              'primes': []}
    for p in [7, 11, 19]:
        squares, Q, f, roots, coeff = spectral_data(p)
        profiles = [certify_profile(p, Q, i, roots, coeff[i])
                    for i, s in enumerate(squares) if s not in [0, 4]]
        tower = tower_checks(p, roots, coeff, squares)
        record = {'p': p, 'quotient': Q, 'folded_classes': squares,
                  'characteristic_polynomial': str(f.as_expr()),
                  'isolated_roots': [[str(r['lo']), str(r['hi'])] for r in roots],
                  'generic_field_profiles': profiles, 'tower_sign_checks': tower,
                  'all_field_and_tower_profiles_unimodal': True}
        result['primes'].append(record)
        print({'p': p, 'generic_field_profiles': len(profiles),
               'finite_interval_leaves': sum(len(q['certified_partition']) for q in profiles),
               'tower_checks': tower, 'result': 'passed'}, flush=True)
    Path('output').mkdir(exist_ok=True)
    Path('output/Small_Prime_Unimodality_Verification.json').write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
