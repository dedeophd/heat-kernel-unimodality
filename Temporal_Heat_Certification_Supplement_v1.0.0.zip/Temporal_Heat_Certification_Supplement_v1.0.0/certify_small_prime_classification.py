"""Reproduce the finite ingredients of the sharp prime-threshold theorem.

The all-level analytic reduction is proved in the accompanying manuscript.
This program covers the positive field profiles and failures at 23 and 31;
run_all_checks.py also verifies all 69 bridge records for 43 <= p < 841.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import sympy
import flint
from certify_small_prime_unimodality import main as certify_positive
from generate_prime_bridge import produce
from verify_prime_bridge import geometric_quotient, verify_record


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def main():
    certify_positive()
    negative = [produce(p, order=320) for p in [23, 31]]
    out = Path('output')
    out.mkdir(exist_ok=True)
    (out/'Small_Prime_Failure_Certificates.json').write_text(json.dumps({
        'status': 'complete', 'scope': 'p=23,31; every ring level by localization',
        'records': negative}, indent=2)+'\n')
    checks = [verify_record(record, 'python') for record in negative]
    (out/'Small_Prime_Failure_Verification.json').write_text(json.dumps(checks, indent=2)+'\n')
    gains = []
    expected = {3: F(3, 4), 7: F(21, 32), 11: F(55, 108), 19: F(171, 250),
                23: F(253, 432), 31: F(1395, 2048)}
    for p, ep in expected.items():
        squares, Q = geometric_quotient(p)
        v = [int(s == 0) for s in squares]  # per-vertex one-step path counts
        for _ in range(2):
            v = [sum(a*b for a, b in zip(row, v)) for row in Q]
        third = [F(p*(p-1)*x, (p+1)**3) for x in v]
        adjusted = third[:]
        adjusted[squares.index(0)] -= F(4*p*(p-1), (p+1)**3)
        require(min(adjusted) == ep, 'exact all-level minorization coefficient')
        gains.append({'p': p, 'epsilon': str(ep), 'gain_upper': str(6/ep),
                      'all_level_profile_classification': 'unimodal' if p < 23 else 'failure'})
    summary = {
        'scope': 'p prime, p=3 mod 4, delta=-1, middle parameter, all Z/p^nZ levels',
        'unimodal_primes': [3, 7, 11, 19],
        'failure_primes_below_43': [23, 31],
        'sharp_failure_threshold': 23,
        'fixed_delta_2_within_proved_scope': {'prime_class': 'p=3 mod 8', 'unimodal_primes': [3,11,19], 'least_failure_prime': 43},
        'infinite_tail_dependency': 'earlier theoretical p>=841 theorem and exact bridge for 43<=p<841',
        'p3_dependency': 'earlier all-level analytic theorem, not reproved by this program',
        'uniform_gain_bound_all_primes_and_levels': '648/55',
        'finite_gain_coefficients': gains,
        'certificate_versions': {'sympy': sympy.__version__, 'python_flint': flint.__version__},
        'publication_status': 'computer-assisted proof draft; external mathematical audit and originality review pending',
        'chapter_comparison': '1993 full chapter supplied and reviewed; forced zeros and symmetry credited; targeted priority review remains distinct from external proof review',
        'uniform_bound_dependency': 'p=3 uses exact three-step minorization 3/4, so no decimal sharp-constant dependency'
    }
    (out/'Small_Prime_Classification.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
