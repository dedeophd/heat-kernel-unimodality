"""Check the frozen archive before regenerating output; standard library only."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS'
records = manifest.read_text().splitlines()
expected = set()
for line in records:
    digest, name = line.split('  ', 1)
    path = (root / name).resolve()
    if not path.is_relative_to(root) or name in expected:
        raise RuntimeError('Invalid checksum path: ' + name)
    expected.add(name)
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise RuntimeError('Release checksum failed: ' + name)
actual = {str(p.relative_to(root)) for p in root.rglob('*')
          if p.is_file() and '__pycache__' not in p.parts and p != manifest}
if actual != expected:
    raise RuntimeError('Release file list differs from SHA256SUMS')
print('Release checksums passed:', len(records), 'files')
