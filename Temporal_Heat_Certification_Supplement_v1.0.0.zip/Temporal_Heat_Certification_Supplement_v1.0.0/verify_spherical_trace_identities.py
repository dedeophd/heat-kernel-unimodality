"""Exact cyclotomic checks of the spherical trace normalization.
Diagnostics for the stated small fields; no prime-threshold or cohomology proof.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json

def require(x,msg):
    if not x:raise ArithmeticError(msg)
def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def exact_div(a,b):
    a=list(a);q=[0]*max(1,len(a)-len(b)+1)
    while len(a)>=len(b) and a!=[0]:
        k=len(a)-len(b);c=a[-1];require(b[-1]==1,'monic division')
        q[k]=c
        for i,x in enumerate(b):a[k+i]-=c*x
        trim(a)
    require(a==[0],'exact division remainder')
    return trim(q)
@lru_cache(None)
def cyclotomic(n):
    a=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d==0:a=exact_div(a,cyclotomic(d))
    return tuple(a)
class Ring:
    def __init__(self,n):self.n=n;self.mod=cyclotomic(n);self.D=len(self.mod)-1;self.zero=(0,)*self.D
    def reduce(self,a):
        a=list(a)
        while len(a)>self.D:
            c=a[-1];k=len(a)-len(self.mod)
            if c:
                for i,b in enumerate(self.mod):a[k+i]-=c*b
            a.pop()
        return tuple(a+[0]*(self.D-len(a)))
    def const(self,c):return (c,)+(0,)*(self.D-1)
    def root(self,k):return self.reduce([0]*(k%self.n)+[1])
    def add(self,a,b):return tuple(x+y for x,y in zip(a,b))
    def scale(self,c,a):return tuple(c*x for x in a)
    def mul(self,a,b):
        out=[0]*(2*self.D-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):out[i+j]+=x*y
        return self.reduce(out)
def chi(x,p):
    x%=p
    return 0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1)
def field_generator(p):
    for g in range(2,p):
        if len({pow(g,j,p) for j in range(p-1)})==p-1:return g
    return 2

def norm_generator(p):
    def mul(z,w):return ((z[0]*w[0]-z[1]*w[1])%p,(z[0]*w[1]+z[1]*w[0])%p)
    for a in range(p):
        for b in range(p):
            if (a*a+b*b)%p!=1:continue
            z=(1,0);ls=[]
            for j in range(p+1):ls.append(z);z=mul(z,(a,b))
            if len(set(ls))==p+1:return ls
    raise ArithmeticError('no norm generator')
def quotient(p):
    V=[(x,y) for x in range(p) for y in range(1,p)]
    S=[g for g in V if (g[0]**2+g[1]**2+1)%p==0]
    inv=[0]+[pow(y,-1,p) for y in range(1,p)]
    def label(x,y):return (x*x+(y-1)**2)*inv[y]%p
    rows={};sizes=Counter(label(*g) for g in V)
    for x,y in V:
        a=label(x,y);r=Counter(label((x+y*u)%p,y*v%p) for u,v in S)
        if a in rows:require(rows[a]==r,'equitable quotient')
        else:rows[a]=r
    return [[rows[a][b] for b in range(p)] for a in range(p)],sizes
records=[]
for p in [3,7,11,19]:
    d=p+1;N=p*(p-1);M,sizes=quotient(p);fieldg=field_generator(p)
    logs={pow(fieldg,j,p):j for j in range(p-1)};unorm=norm_generator(p)
    types=[];dimension_sum=1
    for kind,ks,n in [('principal',range(1,(p-1)//2+1),p-1),('cuspidal',range(1,(p+1)//2),p+1)]:
        R=Ring(n)
        for k in ks:
            roots=[R.root(k*j) for j in range(n)]
            def lam(u):
                out=R.zero
                if kind=='principal':
                    for y in range(1,p):
                        count=1+chi(-(u*y+(y-1)**2),p)
                        out=R.add(out,R.scale(count,roots[logs[y]]))
                else:
                    for j,z in enumerate(unorm):out=R.add(out,R.scale(-chi(u-2-2*z[0],p),roots[j]))
                return out
            v=[]
            for a in range(p):
                if a==0:v.append(R.const(d))
                elif a==(p-4)%p:v.append(R.const(d*((-1)**k)*(1 if kind=='principal' else -1)))
                else:v.append(lam((-a)%p))
            middle=lam(2)
            for a in range(p):
                lhs=R.zero
                for b in range(p):lhs=R.add(lhs,R.scale(M[a][b],v[b]))
                require(lhs==R.mul(middle,v[a]),f'eigenvector p={p} {kind} k={k} a={a}')
            rank=(p if k==(p-1)//2 else p+1) if kind=='principal' else p-1
            norm=R.zero
            for a in range(p):norm=R.add(norm,R.scale(sizes[a],R.mul(v[a],v[a])))
            require(N*d*d%rank==0,'norm integer')
            require(norm==R.const(N*d*d//rank),f'rank/norm p={p} {kind} k={k}')
            dimension_sum+=rank
            types.append({'kind':kind,'character_index':k,'component_rank':rank,'cyclotomic_order':n})
    require(len(types)+1==p and dimension_sum==N,'complete component count')
    records.append({'p':p,'vertices':N,'component_dimensions_sum':dimension_sum,'nonconstant_components':types})
    print('All cyclotomic eigenfunction and rank checks passed at p =',p,flush=True)
Path('output').mkdir(exist_ok=True)
Path('output/Spherical_Trace_Verification.json').write_text(json.dumps({'arithmetic':'integer polynomial arithmetic modulo cyclotomic polynomials','purpose':'normalization diagnostics, not proof of a universal collision bound','primes':records},indent=2)+'\n')
