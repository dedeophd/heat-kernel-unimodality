"""Produce exact finite-prime heat certificates; no floating point.

The proof of the folded quotient formula is in the accompanying note.
Requires python-flint for production speed. Verification has a standard-library
fallback and builds the quotient directly from graph neighbors.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial, isqrt
import argparse, hashlib, json, time
from flint import fmpz_mat

def require(x,msg):
    if not x:raise ArithmeticError(msg)
def prime(p):return p>=2 and all(p%d for d in range(2,isqrt(p)+1))
def characters(p):
    out=[-1]*p;out[0]=0
    for x in range(1,p):out[x*x%p]=1
    return out
def matrix_hash(Q):
    return hashlib.sha256(('\n'.join(','.join(map(str,r)) for r in Q)+'\n').encode()).hexdigest()
def quotient(p):
    chi=characters(p);squares=sorted({x*x%p for x in range(p)})
    Q=[[(1 if z==0 else 2)*(1-chi[(s+z-4)%p]) for z in squares] for s in squares]
    Q[squares.index(4)][0]+=p
    weights=[p+1 if s==0 else (2 if s==4 else 2*(p+1)) for s in squares]
    require(len(squares)==(p+1)//2 and sum(weights)==p*(p-1),'class sizes')
    require(all(sum(r)==p+1 for r in Q),'quotient degree')
    require(all(weights[i]*Q[i][j]==weights[j]*Q[j][i]
                for i in range(len(Q)) for j in range(len(Q))),'weighted symmetry')
    return squares,Q,chi
def witness_vertex(p,s):
    roots={}
    for x in range(p):roots.setdefault(x*x%p,x)
    a=(roots[s]-2)%p
    for y in range(1,p):
        rhs=((a+2)*y-y*y-1)%p
        if rhs in roots:
            x=roots[rhs]
            require(((x*x+(y-1)**2)*pow(y,-1,p)+2)**2%p==s,'vertex label')
            return a,[x,y]
    raise ArithmeticError('missing representative')

def exact_paths(Q,order):
    n=len(Q);M=fmpz_mat(Q)
    v=fmpz_mat(n,1,[int(i==0) for i in range(n)])
    paths=[None,v]
    for _ in range(2,order+1):v=M*v;paths.append(v)
    return paths

def bounds_all(p,paths,t,order):
    """Common-denominator integer evaluation, independently rechecked later."""
    a,b=t.numerator,t.denominator;d=p+1;N=p*(p-1);n=paths[1].nrows()
    S=fmpz_mat(n,1);weight=a**order
    for j in range(order,0,-1):
        S+=paths[j]*weight
        weight=weight*(b*d)*j//a
    eweight=a**order;E=0
    for j in range(order,-1,-1):
        E+=eweight
        if j:eweight=eweight*b*j//a
    base=d**order*E
    rn=d**order*a**(order+1)*(order+2)
    rd=(order+1)*(b*(order+2)-a)
    require(rd>0,'exponential tail ratio')
    lo_den=base*rd+rn;hi_den=base*rd
    return {'S':[int(S[i,0]) for i in range(n)],'rd':rd,'rn':rn,
            'lo_den':lo_den,'hi_den':hi_den,'N':N,'time':[a,b]}
def interval(data,i):
    S=data['S'][i];rd=data['rd'];N=data['N'];rn=data['rn']
    return F(N*S*rd,data['lo_den']),F(N*(S*rd+rn),data['hi_den'])
def encode_interval(pair):
    return {'lower':str(pair[0]),'upper':str(pair[1])}
def produce(p,order=240):
    started=time.monotonic();squares,Q,chi=quotient(p);paths=exact_paths(Q,order)
    targets=[i for i,s in enumerate(squares) if s not in [0,4] and chi[(s-4)%p]==-1]
    early={t:bounds_all(p,paths,t,order) for t in [F(3),F(4),F(5),F(6)]}
    best=None
    for t2 in map(F,[8,10,12,16,20,24,32,40,48,56,64,80]):
        late=bounds_all(p,paths,t2,order)
        for i in targets:
            # Test strict inequalities using integers before constructing fractions.
            S=late['S'][i]
            if late['N']*(S*late['rd']+late['rn'])>=late['hi_den']:continue
            for t1,data in early.items():
                if data['N']*data['S'][i]*data['rd']<=data['lo_den']:continue
                aa=interval(data,i);bb=interval(late,i)
                margin=min(aa[0]-1,1-bb[1])
                if best is None or margin>best[0]:best=(margin,i,t1,t2,aa,bb,data,late)
        if best is not None:break
    require(best is not None,f'no exact certificate on the prescribed time grid for p={p}')
    margin,i,t1,t2,aa,bb,data,late=best;s=squares[i];a,g=witness_vertex(p,s)
    exponent=1
    while margin<=F(1,10**exponent):exponent+=1
    record={'p':p,'delta':-1,'degree':p+1,'vertices':p*(p-1),
            'folded_classes':len(Q),'quotient_sha256':matrix_hash(Q),
            's':s,'a':a,'vertex':g,'order':order,
            'both_margins_strictly_greater_than_10_to_negative':exponent,
            'above':{'time':[t1.numerator,t1.denominator],'weighted_path_sum':str(data['S'][i]),
                     'density':encode_interval(aa),'margin_lower':str(aa[0]-1)},
            'below':{'time':[t2.numerator,t2.denominator],'weighted_path_sum':str(late['S'][i]),
                     'density':encode_interval(bb),'margin_lower':str(1-bb[1])}}
    print(json.dumps({'p':p,'s':s,'times':[str(t1),str(t2)],
                      'both_margins_gt_10_to_negative':exponent,
                      'seconds':round(time.monotonic()-started,3)}),flush=True)
    return record

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prime',type=int)
    ap.add_argument('--output',default='output/Prime_43_Bridge_Certificates.json')
    args=ap.parse_args()
    ps=[args.prime] if args.prime else [p for p in range(43,841,4) if prime(p)]
    require(all(prime(p) and p%4==3 and 43<=p<841 for p in ps),'prime scope')
    records=[];out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    for p in ps:
        records.append(produce(p))
        out.write_text(json.dumps({'method':'integer paths and rational exponential enclosures',
            'status':'complete' if len(records)==len(ps) else 'partial',
            'scope':'all primes p = 3 mod 4, 43 <= p < 841' if not args.prime else 'single-prime diagnostic',
            'records':records},indent=2)+'\n')
    print('Exact certificates produced:',len(records),flush=True)
if __name__=='__main__':main()
