"""Exact diagnostics for the Chen normalization and the middle graph's spectrum.

No floating-point arithmetic is used. Gauss sums are compared coefficient by
coefficient in the additive p-th root before imposing its cyclotomic relation.
The finite checks support conventions; the note supplies the general proof.
"""
import ast
from math import gcd, isqrt
from pathlib import Path
import json

# Reuse only the elementary cyclotomic-ring definitions, not that file's tests.
source = Path(__file__).with_name('verify_spherical_trace_identities.py')
tree = ast.parse(source.read_text())
prefix = []
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'records' for t in node.targets):
        break
    prefix.append(node)
exec(compile(ast.Module(body=prefix, type_ignores=[]), str(source), 'exec'))


def extension(p):
    def mul(z, w):
        return ((z[0]*w[0]-z[1]*w[1]) % p,
                (z[0]*w[1]+z[1]*w[0]) % p)
    order = p*p-1
    factors = [q for q in range(2, order+1)
               if order % q == 0 and all(q % t for t in range(2, isqrt(q)+1))]
    def power(z, k):
        out = (1, 0)
        while k:
            if k & 1:
                out = mul(out, z)
            z = mul(z, z)
            k //= 2
        return out
    for a in range(p):
        for b in range(p):
            h = (a, b)
            if h != (0, 0) and all(power(h, order//q) != (1, 0) for q in factors):
                values = [(1, 0)]
                for _ in range(order-1):
                    values.append(mul(values[-1], h))
                require(len(set(values)) == order, 'extension generator')
                return values, {z: j for j, z in enumerate(values)}
    raise ArithmeticError('extension generator missing')


records = []
for p in [3, 7, 11, 19, 23, 43, 59, 83]:
    d = p+1
    R = Ring(2*d)
    roots = [R.root(j) for j in range(2*d)]
    values, logs = extension(p)
    us = [values[(p-1)*j] for j in range(d)]
    components = []
    for k in range(1, d//2, 2):
        e = d//2-k
        v = d//gcd(k, d)
        require(2*d//gcd(e, 2*d) == 2*v, 'eta has order 2v')
        require(roots[e*d % (2*d)] == R.const(-1), 'eta restricts to phi')
        kap = R.zero
        for j, (a, b) in enumerate(us):
            kap = R.add(kap, R.scale(chi(2*a, p), roots[2*k*j % (2*d)]))
        require(kap != R.zero, 'eligible cuspidal eigenvalue is nonzero')
        coeff = [R.zero for _ in range(p)]
        jac = R.zero
        jacbar = R.zero
        for j, (a, b) in enumerate(values):
            eta = roots[e*j % (2*d)]
            coeff[2*a % p] = R.add(coeff[2*a % p], R.scale(1+(-1)**j, eta))
            y = ((1-a) % p, -b % p)
            phi_y = 0 if y == (0, 0) else (-1)**logs[y]
            jac = R.add(jac, R.scale(phi_y, eta))
            jacbar = R.add(jacbar, R.scale(phi_y, roots[-e*j % (2*d)]))
        for t in range(p):
            require(coeff[t] == R.scale(chi(t, p), kap),
                    f'Chen Gauss coefficient p={p}, k={k}, t={t}')
        require(R.add(jac, jacbar) == R.add(R.mul(kap, kap), R.const(-2*p)),
                f'Jacobi square trace p={p}, k={k}')
        components.append(kap)
    require(len(set(components)) == d//4, 'distinct cuspidal components')
    # The two inverse-paired order-12 components are both included at p=11,59,83.
    rec = {'p': p, 'cuspidal_components': len(components),
           'gauss_coefficient_equalities': p*len(components),
           'nonzero_and_distinct': True, 'jacobi_square_traces': True}
    records.append(rec)
    print(rec, flush=True)

Path('output').mkdir(exist_ok=True)
Path('output/Chen_Gauss_Verification.json').write_text(json.dumps({
    'arithmetic': 'integer polynomial arithmetic modulo cyclotomic polynomials',
    'identity': 'kappa*G_p(phi) = G_Q(eta) + G_Q(Phi*eta)',
    'graph_sign': 'kappa = -(alpha + conjugate(alpha)), alpha = -G_Q(eta)/G_p(phi)',
    'proof_scope': 'finite normalization diagnostics, not a universal separation proof',
    'primes': records,
}, indent=2)+'\n')
print('All exact Chen/Gauss normalization checks passed.')
