TEMPORAL HEAT CERTIFICATION: COMPUTATIONAL SUPPLEMENT
Version 1.0.0 -- 19 October 2026 (America/New_York)

PURPOSE
This is the computational companion to the manuscript on temporal unimodality
of heat kernels on finite upper half-plane towers. The accompanying manuscript,
not a historical Gate report, is the authoritative source of the general proofs.
This release replaces the earlier Threshold_Arithmetic_Package review packet.
No repository DOI has been assigned to this release.

QUICK START
Unzip the archive, open a terminal in the extracted supplement directory, and run:
    python verify_release.py
    python -m pip install -r requirements.txt
    python -O run_all_checks.py
The mathematical runner works from any current directory when called by its
full path. It writes regenerated records and logs to output/ and stops at the
first failed job. A complete successful run reports nine passed jobs and writes
output/Verification_Summary.json with nine zero return codes.
Tested interpreter: CPython 3.12.14. Pinned libraries: SymPy 1.14.0,
python-flint 0.9.0 (including Arb), and mpmath 1.3.0. The positive certifier
uses 384-bit interval arithmetic. The optimized Python flag does not remove
the explicit mathematical proof guards.

ARCHIVE CONTENTS
README.txt: reproduction instructions and scope.
PROOF_MAP.txt: relation between programs and manuscript claims.
CITATION.cff: software citation metadata (no DOI).
RELEASE.json: release and input provenance, versions, coverage, and limits.
SHA256SUMS: hashes of all other released files, including frozen output.
verify_release.py: standard-library validation of those file hashes.
requirements.txt: pinned mathematical runtime dependencies.
*.py: verification and certificate-generation source programs.
Prime_43_Bridge_Certificates.json: complete 69-record input certificate file.
output/: freshly generated certificates, verification reports, and job logs.

The historical word "Bridge" and the number 43 in the input filename identify
the 69 primes 43 <= p < 841; they do not claim that 43 is the least failing
prime. Failures at 23 and 31 are generated and verified by the small-prime job.
The expected number of negative certificates is therefore 71, not 69.

WHAT THE RUNNER CHECKS
1. Integer field walk/curve identities and rational overshoot bounds.
2. Exact cyclotomic spherical trace and rank diagnostics.
3. Jacobi-sum, reduction-pattern, and collision diagnostics at tested primes.
4. Exact Chen/Gauss normalization diagnostics.
5. The F_9 collision boundary case (not a ring-level classification).
6. Direct ring identities in five cases, covering 20,282 vertices.
7. All 14 positive generic field profiles for 7,11,19, related coefficient
   signs, rational failures for 23,31, and exact small-prime minorization.
8. All 69 input bridge records, independently rebuilding the quotient from
   graph neighbors and checking integer walks and rational heat enclosures.
9. The p=43 record again with the standard-library integer backend.

VERIFICATION AND REGENERATION
verify_release.py checks the frozen release bytes BEFORE running other jobs.
The runner regenerates output, and elapsed times and environment metadata may
change. Thus a checksum mismatch after a rerun is expected for changed outputs;
compare against a fresh extraction to check the distributed archive.
All 71 negative certificates and the 14 positive profile certificates are
included in output/. The two small-prime failures and all positive profiles
are regenerated during the main run. To independently regenerate the other
69 negative input records, run from this directory:
    python -O generate_prime_bridge.py --output output/Regenerated_Bridge_Certificates.json
    python -O verify_prime_bridge.py output/Regenerated_Bridge_Certificates.json --output output/Regenerated_Bridge_Verification.json
Full bridge generation is optional and substantially slower than verification.

MATHEMATICAL SCOPE
The manuscript treats primes p = 3 mod 4, the nonsquare parameter -1, the
middle graph parameter, and ring levels Z/p^n Z. Its positive primes are
3,7,11,19; every other admissible prime fails at all levels. The finite files
do not mechanically prove the analytic tail p >= 841, arithmetic separation
for every prime, the cohomological sign theorem, or the all-level reductions.
Those arguments are in the manuscript. The p=3 positive case is analytic.
Sampled plots, floating-point guesses, and hash agreement alone are not the
certification criteria. The exact rational and interval tests are described
in Appendix B. This release does not establish publication priority.

RELEASE NOTES
Version 1.0.0 removes historical reports and duplicate stale root-level output
from the review packet. It retains the mathematical algorithms, adds explicit
release documentation, pins the tested transitive dependency mpmath, and records
fresh verification output. The all-checks runner adds interpreter/platform/time
metadata and uses the neutral output name Verification_Summary.json.
