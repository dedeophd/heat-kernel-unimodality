"""Integer checks of the symbolic path/curve identities; not a prime-threshold proof.
No numerical eigenvalues, floating point, or third-party dependencies are used.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
from math import isqrt, factorial

def require(statement,message):
    if not statement:raise ArithmeticError(message)
def prime(p):return p>=2 and all(p%d for d in range(2,1+isqrt(p)))
def multiply(M,v):return [sum(a*b for a,b in zip(row,v)) for row in M]
def chi(a,p):
    a%=p
    return 0 if a==0 else (1 if pow(a,(p-1)//2,p)==1 else -1)
records=[]
for p in [q for q in range(3,104) if q%4==3 and prime(q)]:
    d=p+1;N=p*(p-1)
    vertices=[(x,y) for x in range(p) for y in range(1,p)]
    sphere=[(x,y) for x,y in vertices if (x*x+y*y+1)%p==0]
    inv=[0]+[pow(y,-1,p) for y in range(1,p)]
    def label(x,y):return (x*x+(y-1)**2)*inv[y]%p
    reps={};rows={}
    for x,y in vertices:
        a=label(x,y)
        row=Counter(label((x+y*u)%p,y*v%p) for u,v in sphere)
        if a in rows:require(rows[a]==row,'inequitable quotient')
        else:rows[a]=row;reps[a]=(x,y)
    M=[[rows[a][b] for b in range(p)] for a in range(p)]
    v0=[int(a==0) for a in range(p)];v2=multiply(M,multiply(M,v0));v3=multiply(M,v2)
    require(len(sphere)==d,'degree')
    generic=0
    for a,(X,Y) in reps.items():
        require(v2[a]==1-chi(a*(a+4),p)+p*int(a in [0,(p-4)%p]),'two step')
        if a in [0,(p-4)%p]:require(v3[a]==2*d,'source/antipode');continue
        if a==p-2:require(v3[a]==4*p,'sphere');continue
        r=(X*X+Y*Y)%p;c=(r-1)%p
        def Q(z):return ((c-2*X*z)**2+4*Y*Y*(1+z*z))%p
        quartic_sum=sum(chi((z*z+1)*Q(z),p) for z in range(p))
        curve_points=p+1+chi(r,p)+quartic_sum
        trace=p+1-curve_points
        require(v3[a]==d-trace,'elliptic path identity')
        require(trace*trace<=4*p,'Hasse')
        require(sum(chi(Q(z),p) for z in range(p))==-chi(r,p),'quadratic sum')
        if X:
            z=c*pow(2*X,-1,p)%p;w=2*Y*(1+z*z)%p
            require((w*w-(1+z*z)*Q(z))%p==0,'rational point')
        else:require(chi(r,p)==1,'points at infinity')
        generic+=1
    sizes=Counter(label(*g) for g in vertices)
    require(sum(sizes[a] for a in range(p) if a not in [0,(p-4)%p,p-2] and v2[a]==2)==d*(p-3)//2,'two path set size')
    rec={'p':p,'all_vertices_equitable':N,'generic_curve_classes_checked':generic}
    records.append(rec)
    print(rec,flush=True)
# The refined analytic threshold uses rational comparisons and e^(15/4) < 213/5.
T=F(15,4);E=F(213,5)
S=sum((T**j)/factorial(j) for j in range(31))
first=T**31/factorial(31)
require(S+first/(1-T/32)<E,'exponential bound')
K0=F(841*840,842**2);eps0=K0*(1-F(58,842));c=1+T+T*T/2
margin=K0*T*T-eps0*c-(1-eps0)*E
require(margin==F(18261261,2984738440),'exact overshoot bracket')
require(margin/E==F(6087087,42383285848) and margin/E>F(1,7000),'threshold arithmetic')
result={'purpose':'integer diagnostics for independently proved identities; finite checks are not a proof of the cohomological sign theorem','primes':records,'overshoot_threshold_arithmetic':'6087087/42383285848 > 1/7000 for p >= 841','exponential_upper_bound':'e^(15/4) < 213/5'}
Path('output').mkdir(exist_ok=True)
Path('output/Threshold_Arithmetic_Verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('All exact checks passed.')
