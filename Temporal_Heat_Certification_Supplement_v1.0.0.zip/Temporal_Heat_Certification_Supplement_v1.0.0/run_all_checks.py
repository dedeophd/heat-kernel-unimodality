"""Reproduce all finite checks in supplement version 1.0.0.

This does not mechanically verify the analytic proofs or establish priority.
Run with the pinned requirements installed, from any working directory.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
import platform
from datetime import datetime, timezone
import sympy
import flint


def main():
    root = Path(__file__).resolve().parent
    out = root/'output'
    out.mkdir(exist_ok=True)
    if sympy.__version__ != '1.14.0' or flint.__version__ != '0.9.0':
        raise RuntimeError('Use requirements.txt: SymPy 1.14.0, python-flint 0.9.0')
    jobs = [
        ['verify_threshold_arithmetic.py'],
        ['verify_spherical_trace_identities.py'],
        ['verify_collision_bound.py'],
        ['verify_chen_gauss_identity.py'],
        ['verify_field9_boundary.py'],
        ['verify_tower_identities.py'],
        ['certify_small_prime_classification.py'],
        ['verify_prime_bridge.py', 'Prime_43_Bridge_Certificates.json',
         '--output', 'output/Prime_43_Bridge_Verification.json'],
        ['verify_prime_bridge.py', 'Prime_43_Bridge_Certificates.json',
         '--prime', '43', '--backend', 'python',
         '--output', 'output/Bridge_Standard_Library_Recheck.json'],
    ]
    records = []
    for args in jobs:
        name = args[0].removesuffix('.py')
        if '--backend' in args:
            name += '_standard_library'
        log = out/(name+'.log')
        start = time.monotonic()
        with log.open('w') as stream:
            result = subprocess.run([sys.executable, '-O', *args], cwd=root,
                                    stdout=stream, stderr=subprocess.STDOUT)
        record = {'command': ['python', '-O', *args], 'returncode': result.returncode,
                  'elapsed_seconds': round(time.monotonic()-start, 3),
                  'log': 'output/'+log.name,
                  'script_sha256': hashlib.sha256((root/args[0]).read_bytes()).hexdigest()}
        records.append(record)
        print(name, 'passed' if result.returncode == 0 else 'FAILED', flush=True)
        if result.returncode:
            raise RuntimeError('Failed check; inspect '+str(log))
    (out/'Verification_Summary.json').write_text(json.dumps({
        'status': 'all finite checks passed', 'release_version': '1.0.0',
        'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'python': platform.python_version(), 'platform': platform.platform(),
        'records': records,
        'sympy': sympy.__version__, 'python_flint': flint.__version__,
        'limits': ['not a formal verification of the general analytic proofs',
                   'not an external mathematical review', 'not an originality certificate']}, indent=2)+'\n')


if __name__ == '__main__':
    main()
