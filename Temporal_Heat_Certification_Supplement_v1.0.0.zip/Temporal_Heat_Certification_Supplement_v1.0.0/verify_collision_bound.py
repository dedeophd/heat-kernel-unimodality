"""Exact normalization/reduction diagnostics for the arithmetic threshold proof.
The general proof is in the accompanying note; finite checks do not prove a threshold.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json

def require(x,msg):
    if not x:raise ArithmeticError(msg)
def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def exact_div(a,b):
    a=list(a);q=[0]*max(1,len(a)-len(b)+1)
    while len(a)>=len(b) and a!=[0]:
        k=len(a)-len(b);c=a[-1];require(b[-1]==1,'monic division')
        q[k]=c
        for i,x in enumerate(b):a[k+i]-=c*x
        trim(a)
    require(a==[0],'exact division remainder')
    return trim(q)
@lru_cache(None)
def cyclotomic(n):
    a=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d==0:a=exact_div(a,cyclotomic(d))
    return tuple(a)
class Ring:
    def __init__(self,n):self.n=n;self.mod=cyclotomic(n);self.D=len(self.mod)-1;self.zero=(0,)*self.D
    def reduce(self,a):
        a=list(a)
        while len(a)>self.D:
            c=a[-1];k=len(a)-len(self.mod)
            if c:
                for i,b in enumerate(self.mod):a[k+i]-=c*b
            a.pop()
        return tuple(a+[0]*(self.D-len(a)))
    def const(self,c):return (c,)+(0,)*(self.D-1)
    def root(self,k):return self.reduce([0]*(k%self.n)+[1])
    def add(self,a,b):return tuple(x+y for x,y in zip(a,b))
    def scale(self,c,a):return tuple(c*x for x in a)
    def mul(self,a,b):
        out=[0]*(2*self.D-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):out[i+j]+=x*y
        return self.reduce(out)
def chi(x,p):
    x%=p
    return 0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1)
def field_generator(p):
    for g in range(2,p):
        if len({pow(g,j,p) for j in range(p-1)})==p-1:return g
    return 2

def norm_generator(p):
    def mul(z,w):return ((z[0]*w[0]-z[1]*w[1])%p,(z[0]*w[1]+z[1]*w[0])%p)
    for a in range(p):
        for b in range(p):
            if (a*a+b*b)%p!=1:continue
            z=(1,0);ls=[]
            for j in range(p+1):ls.append(z);z=mul(z,(a,b))
            if len(set(ls))==p+1:return ls
    raise ArithmeticError('no norm generator')
def quotient(p):
    V=[(x,y) for x in range(p) for y in range(1,p)]
    S=[g for g in V if (g[0]**2+g[1]**2+1)%p==0]
    inv=[0]+[pow(y,-1,p) for y in range(1,p)]
    def label(x,y):return (x*x+(y-1)**2)*inv[y]%p
    rows={};sizes=Counter(label(*g) for g in V)
    for x,y in V:
        a=label(x,y);r=Counter(label((x+y*u)%p,y*v%p) for u,v in S)
        if a in rows:require(rows[a]==r,'equitable quotient')
        else:rows[a]=r
    return [[rows[a][b] for b in range(p)] for a in range(p)],sizes

from math import comb, gcd

def fp2_generator(p):
    q=p*p
    def mul(z,w):
        return ((z[0]*w[0]-z[1]*w[1])%p,(z[0]*w[1]+z[1]*w[0])%p)
    def power(z,e):
        out=(1,0)
        while e:
            if e&1:out=mul(out,z)
            z=mul(z,z);e//=2
        return out
    divisors=[];v=q-1;l=2
    while l*l<=v:
        if v%l==0:
            divisors.append(l)
            while v%l==0:v//=l
        l+=1
    if v>1:divisors.append(v)
    for a in range(p):
        for b in range(p):
            if (a,b)==(0,0):continue
            if all(power((a,b),(q-1)//l)!=(1,0) for l in divisors):
                vals=[];z=(1,0)
                for _ in range(q-1):vals.append(z);z=mul(z,(a,b))
                require(len(set(vals))==q-1,'field generator')
                return vals,mul,power
    raise ArithmeticError('no extension generator')

def primitive_count(v):
    return sum(1 for a in range(1,v+1) if gcd(a,v)==1) if v==1 else __primitive_count(v)

def __primitive_count(v):
    out=1;l=2
    while l*l<=v:
        if v%l==0:
            e=0
            while v%l==0:v//=l;e+=1
            out*=l-2 if e==1 else (l-1)**2*l**(e-2)
        l+=1
    if v>1:out*=v-2
    return out

records=[]
for p in [3,7,11,19,23,43,59,83]:
    m=(p-1)//2;d=p+1;g=field_generator(p)
    # Principal sums, with the unique odd-order square root eta of chi.
    Rp=Ring(p-1);principal_values=[];principal_rational=[]
    for k in range(2,m,2):
        e=(k//2)*pow(2,-1,m)%m
        # eta index on the full multiplicative group is 2e.
        a=2*e
        J=Rp.zero;Jbar=Rp.zero;kap=Rp.zero
        for j in range(p-1):
            x=pow(g,j,p)
            J=Rp.add(J,Rp.scale(chi(1-x,p),Rp.root(a*j)))
            Jbar=Rp.add(Jbar,Rp.scale(chi(1-x,p),Rp.root(-a*j)))
            kap=Rp.add(kap,Rp.scale(-chi(1+x*x,p),Rp.root(k*j)))
        require(kap==Rp.scale(-1,Rp.add(J,Jbar)),f'principal Jacobi trace p={p} k={k}')
        require(kap!=Rp.zero,'nonzero even principal eigenvalue')
        require(kap not in principal_values,'distinct principal components')
        principal_values.append(kap)
        if all(x==0 for x in kap[1:]):principal_rational.append(kap[0])
    # Cuspidal split-torus trace and Gauss-square/Jacobi normalization.
    values,mul,power=fp2_generator(p);q=p*p
    logs={z:j for j,z in enumerate(values)}
    unorm=[values[(p-1)*j] for j in range(d)]
    R=Ring(2*d);cuspidal_values=[];cuspidal_rational=[];exceptional_count=0
    for k in range(1,m+1,2):
        kap=R.zero;J=R.zero;Jbar=R.zero
        a=d//2-k
        for j,z in enumerate(unorm):
            kap=R.add(kap,R.scale(chi(2*z[0],p),R.root(2*k*j)))
        for z,j in logs.items():
            w=((1-z[0])%p,-z[1]%p)
            leg=chi(w[0]*w[0]+w[1]*w[1],p)
            J=R.add(J,R.scale(leg,R.root(a*j)))
            Jbar=R.add(Jbar,R.scale(leg,R.root(-a*j)))
        require(R.add(R.mul(kap,kap),R.const(-2*p))==R.add(J,Jbar),
                f'cuspidal split/Jacobi p={p} k={k}')
        require(kap!=R.zero,'nonzero odd cuspidal eigenvalue')
        require(kap not in cuspidal_values,'distinct cuspidal components')
        cuspidal_values.append(kap)
        if all(x==0 for x in kap[1:]):cuspidal_rational.append(kap[0])
        if d//gcd(d,k)==12:
            require(any(x!=0 for x in kap[1:]),'exceptional order 12 is irrational')
            require(p%24==11,'exceptional prime class')
            exceptional_count+=1
    require(set(principal_rational).isdisjoint(cuspidal_rational),'no cross-family rational collisions')
    # Principal and cuspidal Jacobi zero-reduction patterns for every eligible order.
    for v in range(3,m+1,2):
        if m%v:continue
        for a in range(1,v):
            if gcd(a,v)>1:continue
            e=(p-1)*a//v
            residue=sum(pow(x,e,p)*pow((1-x)%p,m,p) for x in range(1,p))%p
            require((residue==0)==(2*a<v),'principal half-pattern')
    for v in range(4,d+1,4):
        if d%v or (d//v)%2==0:continue
        w=2*v;c=2*(p+1)//w
        for a in range(1,w):
            if gcd(a,w)>1:continue
            e=(q-1)*a//w
            j=q-1-e
            coefficient=0 if j>(q-1)//2 else comb((q-1)//2,j)%p
            require((coefficient==0)==(2*a<w),'cuspidal half-pattern')
            if 2*a>w:
                b=w-a;A=(c*b-1)//2;B=(p-c*b)//2
                require(A+B==m and 0<=A<=m and 0<=B<=m,'Lucas digits')
                require(j==A*p+B,'Lucas digit identity')
    records.append({'p':p,'principal_trace':'passed','cuspidal_trace':'passed',
                    'Jacobi_zero_reduction_patterns':'passed',
                    'principal_distinct_components':len(principal_values),
                    'cuspidal_distinct_components':len(cuspidal_values),
                    'cross_family_separation':'passed using coprime fields and exact rational values',
                    'order_12_components_checked':exceptional_count})
    print('Exact Jacobi trace and reduction checks passed:',p,flush=True)

stabilizers=[]
for v in range(3,2001):
    if v%2==0 and v%8:continue
    units=[a for a in range(1,v) if gcd(a,v)==1]
    lower={a for a in units if 2*a<v}
    H=[h for h in units if all(h*a%v in lower for a in lower)]
    expected={1} if v%2 else ({1,5,7,11} if v==24 else {1,v//2-1})
    require(set(H)==expected,'exact half-stabilizer classification')
    pc=__primitive_count(v)
    # The even eligible class has parity-balanced primitive characters.
    # For odd v, the proof uses the lower bound pc/3.
    factor=3 if v%2 else 2
    require(len(H)*pc<=factor*len(units),'annihilator bound')
    require(len(H)**8<=12**8*v,'explicit stabilizer bound')
    stabilizers.append({'modulus':v,'stabilizer_size':len(H)})

balanced_small=[]
for v in range(3,121):
    if 120%v:continue
    units=[a for a in range(1,v) if gcd(a,v)==1]
    found=[]
    for h in units:
        if h==1 or h*h%v!=1:continue
        if all((2*a<v)!=(2*(a*h%v)<v) for a in units):found.append(h)
    expected={v-1}
    if v%4==0:expected.add(v//2+1)
    if v==24:expected.update([17,19])
    if v==60:expected.update([41,49])
    require(set(found)==expected,'finite exceptional cases in Pomerance-Ulmer classification')
    balanced_small.append({'modulus':v,'balanced_involutions':found})
require(841>289,'single-component sign threshold')
Path('output').mkdir(exist_ok=True)
Path('output/Collision_Bound_Verification.json').write_text(json.dumps({
    'arithmetic':'integer cyclotomic polynomial arithmetic and finite-field sums',
    'purpose':'finite diagnostics, not the proof of a universal theorem',
    'primes':records,'stabilizer_diagnostics':stabilizers,
    'balanced_small_moduli':balanced_small,
    'proved_in_note':{'r_bound':'r_p = 1 for the positive top nonconstant eigenvalue',
                      'sufficient_threshold':'p >= 841; p congruent to 3 modulo 4',
                      'levels':'all n >= 1','delta':'-1'},
    'independent_proof_audit':'pending'},indent=2)+'\n')
print('All collision-bound arithmetic diagnostics passed.',flush=True)
