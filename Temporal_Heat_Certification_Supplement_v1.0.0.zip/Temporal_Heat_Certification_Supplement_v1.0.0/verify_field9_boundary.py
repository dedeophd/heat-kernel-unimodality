"""Exact check of the supplied 1992 paper's middle-parameter F_9 example.

This verifies a scope boundary, not a new result. F_9 is a field and is not Z/9Z.
Requires python-flint for the integer characteristic polynomial.
"""
import json
from pathlib import Path
from flint import fmpz_mat, fmpz_poly


def require(value, message):
    if not value:
        raise ArithmeticError(message)


# a+bi, i^2=2 in characteristic 3, matching the supplied example.
F = [(a, b) for a in range(3) for b in range(3)]
zero = (0, 0)
one = (1, 0)
delta = (1, 1)


def add(x, y):
    return ((x[0]+y[0]) % 3, (x[1]+y[1]) % 3)


def neg(x):
    return (-x[0] % 3, -x[1] % 3)


def sub(x, y):
    return add(x, neg(y))


def mul(x, y):
    return ((x[0]*y[0]+2*x[1]*y[1]) % 3,
            (x[0]*y[1]+x[1]*y[0]) % 3)


def sq(x):
    return mul(x, x)


require(delta not in {sq(x) for x in F}, 'delta must be nonsquare')
V = [(x, y) for x in F for y in F if y != zero]
A = [[int(sq(sub(x, u)) == mul(delta, add(sq(y), sq(v))))
      for u, v in V] for x, y in V]
require(len(V) == 72 and all(sum(row) == 10 for row in A), 'size and degree')
for i in range(72):
    require(A[i][i] == 0, 'no loops')
    require(all(A[i][j] == A[j][i] for j in range(72)), 'symmetric')
x = fmpz_poly([0, 1])
expected = x**36*(x-10)*(x+2)**10*(x+6)**9*(x-4)**16
observed = fmpz_mat(A).charpoly()
require(observed == expected, 'published spectrum must match exact matrix')
require(fmpz_mat(A).rank() == 36, 'rank')
result = {
    'purpose': 'verify a published scope-boundary example; not a new result',
    'field': 'F_9 = F_3[i]/(i^2-2), not Z/9Z',
    'delta': '1+i', 'a': '2 delta', 'vertices': 72, 'degree': 10,
    'characteristic_polynomial': 'X^36 (X-10) (X+2)^10 (X+6)^9 (X-4)^16',
    'rank': 36,
    'collision': 'eigenvalue 4 has multiplicity 16, from two dimension-8 cuspidal components',
    'boundary': 'prime-field component separation does not extend unchanged to all finite fields',
    'interpretation': 'This does not contradict any Z/p^nZ tower theorem in the note.'
}
Path('output').mkdir(exist_ok=True)
Path('output/Field9_Boundary_Verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
