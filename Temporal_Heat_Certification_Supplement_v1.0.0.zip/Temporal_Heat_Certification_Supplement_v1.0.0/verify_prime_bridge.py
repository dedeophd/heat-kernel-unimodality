"""Independent exact verifier of the finite-prime bridge.

Rebuilds quotient rows from actual graph neighbors, rather than the producer's
quadratic-character formula. Re-evaluates heat bounds with Fraction arithmetic,
rather than the producer's integer common-denominator evaluation.
Optional python-flint speeds integer matrix-vector products; --backend python
uses only Python's standard library. No numerical eigensolvers or floats.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import argparse, hashlib, json

def check(x,msg):
    if not x:raise ArithmeticError(msg)
def is_prime(p):return p>=2 and all(p%d for d in range(2,isqrt(p)+1))
def digest(Q):
    raw='\n'.join(','.join(str(x) for x in row) for row in Q)+'\n'
    return hashlib.sha256(raw.encode()).hexdigest()

def geometric_quotient(p):
    inv=[0]+[pow(y,-1,p) for y in range(1,p)]
    squares=sorted({x*x%p for x in range(p)});indices={s:i for i,s in enumerate(squares)}
    representatives={}
    for x in range(p):
        for y in range(1,p):
            r=(x*x+y*y+1)*inv[y]%p;s=r*r%p
            representatives.setdefault(s,(x,y))
        if len(representatives)==len(squares):break
    check(set(representatives)==set(squares),'all folded classes represented')
    roots={}
    for y in range(1,p):roots.setdefault(y*y%p,[]).append(y)
    sphere=[(u,v) for u in range(p) for v in roots.get((-1-u*u)%p,[])]
    check(len(sphere)==p+1,'degree from actual generators')
    Q=[]
    for s in squares:
        x,y=representatives[s];counts=Counter()
        for u,v in sphere:
            X=(x+y*u)%p;Y=y*v%p
            r=(X*X+Y*Y+1)*inv[Y]%p
            counts[r*r%p]+=1
        Q.append([counts[z] for z in squares])
    check(all(sum(row)==p+1 for row in Q),'geometric row sums')
    weights=[p+1 if s==0 else (2 if s==4 % p else 2*(p+1)) for s in squares]
    check(sum(weights)==p*(p-1),'class size total')
    check(all(weights[i]*Q[i][j]==weights[j]*Q[j][i]
              for i in range(len(Q)) for j in range(len(Q))),'geometric reversibility')
    return squares,Q

def selected_paths(Q,i,order,backend):
    n=len(Q);out=[0, int(i==0)]
    if backend=='flint':
        from flint import fmpz_mat
        M=fmpz_mat(Q);v=fmpz_mat(n,1,[int(j==0) for j in range(n)])
        for _ in range(2,order+1):v=M*v;out.append(int(v[i,0]))
    else:
        v=[int(j==0) for j in range(n)]
        sparse=[[(j,a) for j,a in enumerate(row) if a] for row in Q]
        for _ in range(2,order+1):
            v=[sum(a*v[j] for j,a in row) for row in sparse];out.append(v[i])
    return out

def fraction_interval(p,counts,t):
    order=len(counts)-1;N=p*(p-1);d=p+1
    term=F(1);E=F(1);Z=F(0)
    for j in range(1,order+1):
        term*=t/j;E+=term;Z+=term*F(counts[j],d**j)
    first=term*t/(order+1)
    check(t<order+2,'tail ratio')
    R=first/(1-t/(order+2))
    return N*Z/(E+R),N*(Z+R)/E,Z

def verify_record(rec,backend):
    p=rec['p'];check(is_prime(p) and p%4==3,'prime scope')
    check(rec['delta']==-1 and rec['vertices']==p*(p-1) and rec['degree']==p+1,'graph parameters')
    squares,Q=geometric_quotient(p)
    check(len(Q)==rec['folded_classes'] and digest(Q)==rec['quotient_sha256'],'independent geometric quotient hash')
    s=rec['s'];check(s in squares and s not in [0,4],'nonspecial folded orbit')
    i=squares.index(s);check(Q[i][0]==2,'two-path orbit')
    x,y=rec['vertex'];check(0<=x<p and 0<y<p,'vertex field coordinates')
    a=(x*x+(y-1)**2)*pow(y,-1,p)%p
    check(a==rec['a'] and (a+2)**2%p==s,'witness vertex')
    counts=selected_paths(Q,i,rec['order'],backend)
    results={};times=[]
    from math import factorial
    for name in ['above','below']:
        data=rec[name];t=F(*data['time']);times.append(t)
        lo,hi,Z=fraction_interval(p,counts,t)
        check(lo==F(data['density']['lower']) and hi==F(data['density']['upper']),name+' exact interval')
        D=(t.denominator*(p+1))**rec['order']*factorial(rec['order'])
        check(Z*D==int(data['weighted_path_sum']),name+' independent path sum')
        margin=lo-1 if name=='above' else 1-hi
        check(margin>0 and margin==F(data['margin_lower']),name+' strict margin')
        check(margin>F(1,10**rec['both_margins_strictly_greater_than_10_to_negative']),name+' decimal margin')
        results[name]=margin
    check(times[0]<times[1],'time order')
    results['peak_defect_lower']=F(4*(p+1),p*(p-1))*results['below']
    return {'p':p,'s':s,'times':[str(t) for t in times],
            'above_margin':str(results['above']),'below_margin':str(results['below']),
            'peak_formula_defect_lower':str(results['peak_defect_lower']),
            'geometric_quotient':'passed','independent_Fraction_enclosure':'passed'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('certificate',nargs='?',default='Prime_43_Bridge_Certificates.json')
    ap.add_argument('--backend',choices=['auto','flint','python'],default='auto')
    ap.add_argument('--prime',type=int);ap.add_argument('--output',default='Prime_43_Bridge_Verification.json')
    args=ap.parse_args();data=json.loads(Path(args.certificate).read_text())
    records=data['records'];expected=[p for p in range(43,841,4) if is_prime(p)]
    check(data['status']=='complete','complete producer run')
    check([r['p'] for r in records]==expected,'exhaustive prime list, no omissions or duplicates')
    backend=args.backend
    if backend=='auto':
        try:import flint;backend='flint'
        except ImportError:backend='python'
    if args.prime:
        records=[r for r in records if r['p']==args.prime];check(len(records)==1,'selected prime')
    verified=[]
    for rec in records:
        verified.append(verify_record(rec,backend));print('Verified exact bridge certificate:',rec['p'],flush=True)
    out={'status':'passed','scope':'all 69 primes' if not args.prime else 'single selected prime',
         'backend':backend,'arithmetic':'integer paths and Python Fraction',
         'independent_checks':'quotient from actual graph neighbors; rational Taylor enclosures',
         'verified':verified,'requires_general_proof':'quotient equitability, convergence, and tower localization'}
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
    print('Exact bridge verification passed:',len(verified),flush=True)
if __name__=='__main__':main()
